package mil;

public class MCP {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Labyrinth gui = new Labyrinth();
	}

}
