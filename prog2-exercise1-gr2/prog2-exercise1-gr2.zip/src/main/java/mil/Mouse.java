package mil;

import java.util.Random;
import java.util.Stack;

/**
 * The Class Mouse.
 */
public class Mouse extends Thread {

	/** The mouse speed factor. */
	private static int mouseSpeedFactor = 10;

	/** The start x. */
	private int startX;
	
	/** The start y. */
	private int startY;

	/** The actual position x. */
	private int actualPositionX;
	
	/** The actual position y. */
	private int actualPositionY;

	/** The last position x. */
	private int lastPositionX;
	
	/** The last position y. */
	private int lastPositionY;

	/** The way crawled. */
	private Stack<Position> wayCrawled = new Stack<Position>();

	/** The labyrinth. */
	private Labyrinth labyrinth;
	
	/** The show warning. */
	boolean showWarning = true;
	
	/** The exit found. */
	boolean exitFound   = false;
	
	/** The i am done. */
	boolean iAmDone     = false;
	
	/**
	 * Instantiates a new mouse.
	 *
	 * @param lab the lab
	 */
	public Mouse(Labyrinth lab) {
		labyrinth = lab;
		
	}
	
	/**
	 * Instantiates a new mouse.
	 *
	 * @param lab the lab
	 * @param name the name
	 */
	public Mouse(Labyrinth lab, String name) {
		labyrinth = lab;
		setName(name);
	}

	/* (non-Javadoc)
	 * @see java.lang.Thread#run()
	 */
	@Override
	public void run() {
		try {
			findWay(getStartX(),getStartY());
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (StackOverflowError e) {
			e.printStackTrace();
			super.stop();
		}
		System.out.println("End "+getName());
	}

	/**
	 * Movemaus.
	 *
	 * @param x the x
	 * @param y the y
	 */
	public void movemaus(int x,int y) {
		lastPositionX = actualPositionX;
		lastPositionY = actualPositionY;
		actualPositionX=x;
		actualPositionY=y;
		labyrinth.visit(x, y, getName());
	}

	/**
	 * Gets the actual position x.
	 *
	 * @return the actual position x
	 */
	public int getActualPositionX() {
		return actualPositionX;
	}

	/**
	 * Gets the actual position y.
	 *
	 * @return the actual position y
	 */
	public int getActualPositionY() {
		return actualPositionY;
	}

	/**
	 * Gets the last position x.
	 *
	 * @return the last position x
	 */
	public int getLastPositionX() {
		return lastPositionX;
	}

	/**
	 * Gets the last position y.
	 *
	 * @return the last position y
	 */
	public int getLastPositionY() {
		return lastPositionY;
	}

	/**
	 * Gets the mouse speed factor
	 *
	 * @return the mouse speed factor
	 */
	public static int getMouseSpeedFactor() {
		return mouseSpeedFactor;
	}

	/**
	 * Sets the mouse speed factor
	 *
	 * @return the mouse speed factor
	 */
	public static void setMouseSpeedFactor(int mouseSpeedFactor) {
		Mouse.mouseSpeedFactor = mouseSpeedFactor;
	}

	/**
	 * find the way method
	 *
	 * @param x X Coordinate of the labyrinth
	 * @param y Y Coordinate of the labyrinth
	 * @throws InterruptedException the interrupted exception
	 * @throws StackOverflowError the stack overflow error
	 */
	public synchronized void findWay(int x, int y) throws InterruptedException, StackOverflowError {
		if(labyrinth.isExit(x,y)) {
			exitFound = true; 
			Stack<Position> pfad = (Stack<Position>) wayCrawled.clone();
			for(Position pos : pfad){
				labyrinth.setPath(pos);
			}
			labyrinth.drawLabyrinthWays();
			labyrinth.repaint();
			labyrinth.foundDialog(getName());
			wayCrawled.pop();
			showWarning = false;
		} 

		if(this.labyrinth.isWay(x-1,y, true) && !labyrinth.isVisited(x-1,y, getName()) && !exitFound) {
			wayCrawled.push(new Position(x-1,y));
			this.movemaus(x-1,y);
			sleep(mouseSpeedFactor);
			findWay(x-1,y);
		}
		if(this.labyrinth.isWay(x+1,y, true) && !labyrinth.isVisited(x+1,y, getName()) && !exitFound) {
			wayCrawled.push(new Position(x+1,y));
			this.movemaus(x+1,y);
			sleep(mouseSpeedFactor);
			findWay(x+1,y);
		}
		if(this.labyrinth.isWay(x,y-1, true) && !labyrinth.isVisited(x,y-1, getName()) && !exitFound) {
			wayCrawled.push(new Position(x,y-1));
			this.movemaus(x,y-1);
			sleep(mouseSpeedFactor);
			findWay(x,y-1);
		}
		if(this.labyrinth.isWay(x,y+1, true) && !labyrinth.isVisited(x,y+1, getName()) && !exitFound) {
			wayCrawled.push(new Position(x,y+1));
			this.movemaus(x,y+1);
			sleep(mouseSpeedFactor);
			findWay(x,y+1);
		}

		if(wayCrawled.size()>=2 && !exitFound) {
			wayCrawled.pop();
			Position pos = wayCrawled.peek();
			this.movemaus(pos.getX(),pos.getY());
			sleep(mouseSpeedFactor);
			findWay(pos.getX(),pos.getY());
		} else {
			if (showWarning){
				labyrinth.warningDialogEnd();
				showWarning = false;
			}
		}
	} 

	/**
	 * Find start field.
	 *
	 * @return true, if successful
	 */
	public boolean findStartField() {
		boolean found = false;
		int fieldCounter=0;
		int incSize = 1;
		Random r = new Random();
		int currX = r.nextInt(labyrinth.getSizeX());
		int currY = r.nextInt(labyrinth.getSizeY());
		int fields = labyrinth.getSizeX() * labyrinth.getSizeY();
		while(!found && fieldCounter < fields) {
			for(int s = 0; s < incSize; s++){
				if(labyrinth.isWay(currX, currY, false) && !found) {
					found=true;
					setStartX(currX);
					setStartY(currY);
				}
				currX++;
				fieldCounter++;	
			}

			for(int s = 0;s <incSize;s++){
				if(labyrinth.isWay(currX, currY, false) && !found) {
					found=true;
					setStartX(currX);
					setStartY(currY);
				}
				currY++;	
				fieldCounter++;
			}

			for(int s=0;s<incSize;s++){
				if(labyrinth.isWay(currX, currY, false) && !found) {
					found=true;
					setStartX(currX);
					setStartY(currY);
				}
				currX--;	
				fieldCounter++;
			}

			for(int s=0;s<incSize;s++){
				if(labyrinth.isWay(currX, currY, false) && !found) {
					found=true;
					setStartX(currX);
					setStartY(currY);
				}
				currY--;
				fieldCounter++;
			}
			currX--;
			currY--;
			incSize = incSize + 2;
		} 

		if (found) {
			actualPositionX = getStartX();
			actualPositionY = getStartY();
			wayCrawled.push(new Position(getStartX(), getStartY()));
		}
		return found;
	}
	
	/**
	 * Gets the start x.
	 *
	 * @return the start x
	 */
	public int getStartX() {
		return startX;
	}
	
	/**
	 * Sets the start x.
	 *
	 * @param startX the new start x
	 */
	public void setStartX(int startX) {
		this.startX = startX;
		this.actualPositionX= startX;
	}
	
	/**
	 * Gets the start y.
	 *
	 * @return the start y
	 */
	public int getStartY() {
		return startY;
	
	}
	
	/**
	 * Sets the start y.
	 *
	 * @param startY the new start y
	 */
	public void setStartY(int startY) {
		this.startY = startY;
		this.actualPositionY= startY;
	}
}  