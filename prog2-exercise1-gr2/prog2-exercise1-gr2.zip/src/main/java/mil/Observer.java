package mil;

public  interface Observer {
   public void update(Field s);
}
