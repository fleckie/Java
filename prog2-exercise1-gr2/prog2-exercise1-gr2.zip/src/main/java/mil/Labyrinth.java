package mil;

import org.jetbrains.annotations.NotNull;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.*;


/**
 * The Class Labyrinth.
 */

//TODO add Observer

public class Labyrinth extends JComponent implements Observer {

	@Override
	public void update(Field s){
		Field f=(Field)s;
		f.getNames().forEach(name -> drawMouse(name));
		f.getNames().forEach(name -> drawLabyrinthWay(name));
	};

	/** The Constant GAMETITLE. */
	private static final String GAMETITLE = "Mouse im labyrinth";

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/** The Constant ACTION_COMMAND_EXIT. */
	private static final String ACTION_COMMAND_EXIT   = "Exit";

	/** The Constant ACTION_COMMAND_LOAD. */
	private static final String ACTION_COMMAND_LOAD   = "Load";

	/** The Constant ACTION_COMMAND_FILE. */
	private static final String ACTION_COMMAND_FILE   = "File"; 

	/** The menu bar. */
	private JMenuBar	menuBar				= new JMenuBar();

	/** The menu. */
	private JMenu		menu				= new JMenu(ACTION_COMMAND_FILE);

	/** The menu item1. */
	private JMenuItem	menuItem1			= new JMenuItem(ACTION_COMMAND_LOAD);

	/** The menu item3. */
	private JMenuItem	menuItem3			= new JMenuItem(ACTION_COMMAND_EXIT);

	/** The buffer. */
	private BufferedImage buffer = null;

	/** The img mouse. */
	private BufferedImage imgMouse   = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img mouse2. */
	private BufferedImage imgMouse2   = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img path. */
	private BufferedImage imgPath    = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img visited. */
	private BufferedImage imgVisited  = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img visited2. */
	private BufferedImage imgVisited2 = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img visited3. */
	private BufferedImage imgVisited3 = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img wall. */
	private BufferedImage imgWall    = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The img way. */
	private BufferedImage imgWay     = new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);

	/** The Constant WAY. */
	public static final char WAY  = ' '; 

	/** The Constant WALL. */
	public static final char WALL = 'X'; 

	/** The labyrinth. */
	private Field[][] labyrinth =  null;

	/** The size x. */
	private int sizeX = 100;

	/** The size y. */
	private int sizeY = 100;

	/** The mouse. */
	private Mouse mouse;

	/** The mouse2. */
	private Mouse mouse2;

	/** The width. */
	public static int WIDTH  = 6;

	/** The height. */
	public static int HEIGHT = 6;

	/** The button start. */
	private JButton buttonStart = null;

	/** The button end. */
	private JButton buttonEnd   = null;

	/** The label speed. */
	private JLabel		labelSpeed			= new JLabel("Speed (ms): ");

	/** The text field speed. */
	private JTextField	textFieldSpeed		= new JTextField(3);

	/**
	 * Instantiates a new labyrinth.
	 */
	public Labyrinth() {
		init();
		drawLabyrinthBitmaps();
		buffer  = new BufferedImage(100*WIDTH,100*HEIGHT,BufferedImage.TYPE_INT_RGB);
		mouse   = new Mouse(this,"Mouse1");
		mouse2  = new Mouse(this,"Mouse2");
	}

	/**
	 * Start.
	 */
	public void start () {
		mouse.run();
		mouse2.run();
	}

	/**
	 * Gets the size x.
	 *
	 * @return the size x
	 */
	public int getSizeX() {
		return sizeX;
	}

	/**
	 * Sets the size x.
	 *
	 * @param sizeX the new size x
	 */
	public void setSizeX(int sizeX) {
		this.sizeX = sizeX;
	}

	/**
	 * Gets the size y.
	 *
	 * @return the size y
	 */
	public int getSizeY() {
		return sizeY;
	}

	/**
	 * Sets the size y.
	 *
	 * @param sizeY the new size y
	 */
	public void setSizeY(int sizeY) {
		this.sizeY = sizeY;
	}

	public Field[][] getLabyrinth(){
		return labyrinth;
	}

	/**
	 * Inits the.
	 */
	private void init() {
		JFrame gui = new JFrame(GAMETITLE);
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = gui.getContentPane();
		c.setLayout(new BorderLayout(5,5));
		c.add(this,BorderLayout.CENTER);

		JPanel buttonleiste = new JPanel();
		buttonleiste.setLayout(new FlowLayout());
		buttonStart = new JButton("Start game");
		buttonEnd   = new JButton("Exit");
		buttonleiste.add( buttonStart ,BorderLayout.SOUTH);
		buttonleiste.add( buttonEnd, BorderLayout.SOUTH);
		buttonleiste.add(labelSpeed);
		buttonleiste.add(textFieldSpeed);
		textFieldSpeed.setText(Mouse.getMouseSpeedFactor()+"");

		buttonStart.setEnabled(false);
		buttonStart.addActionListener(l -> startGame());
		buttonEnd.addActionListener(l -> System.exit(0));

		menu.add(menuItem1);
		menu.add(menuItem3);
		menuBar.add(menu);
		menuItem1.addActionListener(l -> loadField());

		menuItem3.addActionListener(l -> System.exit(0));
		gui.setJMenuBar(menuBar);

		c.add( buttonleiste,BorderLayout.SOUTH );
		gui.setSize(608,670);
		gui.setVisible(true);
	}

	public void loadField(){
		File f = loadFile();
		if(f != null && createLabyrinth(f.getPath())) {
			getMouse().findStartField();
			getMouse2().findStartField();
			drawLabyrinth();
			drawMouse(getMouse().getName());
			drawMouse(getMouse2().getName());
		} else { 
			warningDialog();
			return;
		}
		buttonStart.setEnabled(true);
	}

	/**
	 * Start game.
	 */
	public void startGame() {
		try {
			int speed = Integer.valueOf(textFieldSpeed.getText());
			Mouse.setMouseSpeedFactor(speed);
		} catch (NumberFormatException e) {
		}
		getMouse().start();
		getMouse2().start();	
	}

	/**
	 * Load file.
	 *
	 * @return the file
	 */
	private File loadFile() {
		File labfile = null;
		JFileChooser fc = new JFileChooser(".");
		int retval  = fc.showOpenDialog(null);
		if(retval == JFileChooser.APPROVE_OPTION){
			labfile = fc.getSelectedFile(); 
		}
		return labfile;
	}

	/**
	 * Found dialog.
	 *
	 * @param name the name
	 */
	public void foundDialog(String name) {
		JOptionPane pane = new JOptionPane();
		JDialog dialog = pane.createDialog(this,GAMETITLE);
		JOptionPane.showMessageDialog(dialog, "Path found "+name ,"Information",JOptionPane.INFORMATION_MESSAGE);		
	}

	/**
	 * Warning dialog.
	 */
	public void warningDialog() {
		JOptionPane pane = new JOptionPane();
		JDialog dialog = pane.createDialog(this,GAMETITLE);
		JOptionPane.showMessageDialog(dialog, "Could not create labyrinth" ,"Error",JOptionPane.ERROR_MESSAGE);		
	}

	/**
	 * Warning dialog end.
	 */
	public void warningDialogEnd() {
		JOptionPane pane = new JOptionPane();
		JDialog dialog = pane.createDialog(this,GAMETITLE);
		JOptionPane.showMessageDialog(dialog, "No more ways found" ,"Information",JOptionPane.INFORMATION_MESSAGE);	
	}

	/**
	 * Warning no place.
	 */
	public void warningNoPlace() {
		JOptionPane pane = new JOptionPane();
		JDialog dialog = pane.createDialog(this,GAMETITLE);
		JOptionPane.showMessageDialog(dialog, "No place for the mouse found" ,"Error",JOptionPane.ERROR_MESSAGE);		
	}


	/* (non-Javadoc)
	 * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
	 */
	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D)g.create();
		g2d.drawImage(buffer,0,0,null);
		g2d.dispose();
	}

	/**
	 * Visit.
	 *
	 * @param x the x
	 * @param y the y
	 * @param name the name
	 */
	public void visit(int x, int y, String name) {
		labyrinth[x][y].setIsVisited(name);
	}	

	/**
	 * Checks if is exit.
	 *
	 * @param x the x
	 * @param y the y
	 * @return true, if is exit
	 */
	public boolean isExit(int x,int y) {
		boolean isExit = false;
		if(x == 0 || (x == sizeX-1) || y == 0 || y == (sizeY-1)) {
			isExit = true;
		} 
		return isExit;
	}

	/**
	 * Checks if is visited.
	 *
	 * @param x the x
	 * @param y the y
	 * @param name the name
	 * @return true, if is visited
	 */
	public boolean isVisited(int x,int y, String name) {
		return labyrinth[x][y].isVisited(name);
	}

	/**
	 * Sets the path.
	 *
	 * @param pos the new path
	 */
	public void setPath(Position pos) {
		labyrinth[pos.getX()][pos.getY()].setPath();
	}


	/**
	 * Creates the labyrinth.
	 *
	 * @param fileName the file name
	 * @return true, if successful
	 */

	public boolean checkLabyrinth(String fileName){
		boolean ok = true;
		Vector<String> lines = new Vector<String>();
		try {
			FileReader fr = new FileReader(fileName);
			Scanner scan = new Scanner(fr);

			while(scan.hasNextLine()){
				lines.add(scan.nextLine());
			}
		}
		catch(FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		}
		return ok;
	}

	public boolean createLabyrinth(String fileName) {

		Vector<String> lines = readLabyrinth(fileName);

		labyrinth = createLabFromFile(lines);

		return true;
	}

	protected Field[][] createLabFromFile(Vector<String> lines) {


		this.sizeX = lines.get(0).length();
		this.sizeY = lines.size();
		Field[][] labyrinth = new Field[this.sizeX][this.sizeY];

		for (int i=0; i<this.sizeY; i++ ){
			for (int j=0; j< this.sizeX; j++){
				labyrinth[j][i] = FieldFactory.setField(lines.elementAt(i).charAt(j));
				labyrinth[j][i].add(this);
			}
		}

		return labyrinth;
	}

	@NotNull
	protected Vector<String> readLabyrinth(String fileName) {
		Vector<String> lines = new Vector<String>();

		try {
			FileReader fr = new FileReader(fileName);
			Scanner scan = new Scanner(fr);

			while(scan.hasNextLine()){
				lines.add(scan.nextLine());
			}
		}
		catch(FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		}
		return lines;
	}


	/**
	 * Draw mouse.
	 *
	 * @param name the name
	 */
	public synchronized void drawMouse(String name) {
		Graphics g = buffer.getGraphics();
		if(mouse.getName().equals(name)){
			g.setColor(Color.red);
			g.drawImage(imgMouse,( mouse.getActualPositionX()*WIDTH),( mouse.getActualPositionY()*HEIGHT),null);
		}
		if(mouse2.getName().equals(name)){
			g.setColor(Color.pink);
			g.drawImage(imgMouse2,(mouse2.getActualPositionX()*WIDTH),(mouse2.getActualPositionY()*HEIGHT),null);
		}
		repaint();
	} 

	/**
	 * Draw labyrinth way.
	 *
	 * @param name the name
	 */
	public synchronized void drawLabyrinthWay(String name) {
		Graphics g = buffer.getGraphics();
		int x = 0;
		int y = 0;
		if(mouse.getName().equals(name)){
			x = mouse.getLastPositionX();
			y = mouse.getLastPositionY();
		}
		if(mouse2.getName().equals(name)){
			x = mouse2.getLastPositionX();
			y = mouse2.getLastPositionY();
		}

		if (labyrinth[x][y].isVisited()) {
			if(labyrinth[x][y].isVisited(mouse.getName()) &&  labyrinth[x][y].isVisited(mouse2.getName())){
				g.drawImage(imgVisited3, (x * WIDTH), (y * HEIGHT), null);
			} else 
				if(labyrinth[x][y].isVisited(mouse.getName())){
					g.drawImage(imgVisited, (x * WIDTH), (y * HEIGHT), null);
				} else
					if(labyrinth[x][y].isVisited(mouse2.getName())){
						g.drawImage(imgVisited2, (x * WIDTH), (y * HEIGHT), null);
					}
		} 
		repaint();
	}

	/**
	 * Check collision.
	 *
	 * @return true, if successful
	 */
	public boolean checkCollision() {
		if((Math.abs(mouse.getActualPositionX()- mouse2.getActualPositionX())<2) && 
				(Math.abs(mouse.getActualPositionY()- mouse2.getActualPositionY())<2)){
			System.out.println("COLLISION mouse1 "+mouse.getActualPositionX()+"/"+mouse.getActualPositionY()+" "+mouse2.getActualPositionX()+"/"+mouse2.getActualPositionY());
			return true; 
		} 
		return false;
	}	

	/**
	 * Draw labyrinth.
	 */
	public void drawLabyrinth() {
		Graphics g = buffer.getGraphics();
		for (int y = 0; y < sizeY; y++) {
			for (int x = 0; x < sizeX; x++) {
				if (labyrinth[x][y].isWall()) {
					g.drawImage(imgWall, (x * WIDTH), (y * HEIGHT), null);
				}
				if (labyrinth[x][y].isWay()) {
					if (labyrinth[x][y].isVisited()) {
						if(labyrinth[x][y].isVisited(mouse.getName()) &&  labyrinth[x][y].isVisited(mouse2.getName())){
							g.drawImage(imgVisited3, (x * WIDTH), (y * HEIGHT), null);
						} else 
							if(labyrinth[x][y].isVisited(mouse.getName())){
								g.drawImage(imgVisited, (x * WIDTH), (y * HEIGHT), null);
							} else
								if(labyrinth[x][y].isVisited(mouse2.getName())){
									g.drawImage(imgVisited2, (x * WIDTH), (y * HEIGHT), null);
								}
					} else {
						g.drawImage(imgWay, (x * WIDTH), (y * HEIGHT), null);
					}
				}
			}
		}
		repaint();
	}

	/**
	 * Draw labyrinth ways.
	 */
	public synchronized void drawLabyrinthWays() {
		Graphics g = buffer.getGraphics();
		for (int y = 0; y < sizeY; y++) {
			for (int x = 0; x < sizeX; x++) {
				if (labyrinth[x][y].isWay()) {
					if (labyrinth[x][y].isPath()) {
						g.drawImage(imgPath, (x * WIDTH), (y * HEIGHT), null);
					} else if (labyrinth[x][y].isVisited()) {
						if (labyrinth[x][y].isVisited()) {
							if(labyrinth[x][y].isVisited(mouse.getName()) &&  labyrinth[x][y].isVisited(mouse2.getName())){
								g.drawImage(imgVisited3, (x * WIDTH), (y * HEIGHT), null);
							} else 
								if(labyrinth[x][y].isVisited(mouse.getName())){
									g.drawImage(imgVisited, (x * WIDTH), (y * HEIGHT), null);
								} else
									if(labyrinth[x][y].isVisited(mouse2.getName())){
										g.drawImage(imgVisited2, (x * WIDTH), (y * HEIGHT), null);
									}
						} 
					} else {
						g.drawImage(imgWay, (x * WIDTH), (y * HEIGHT), null);
					}
				}
			}
		}
	}

	/**
	 * Checks if is way.
	 *
	 * @param x the x
	 * @param y the y
	 * @param checkCollision the check collision
	 * @return true, if is way
	 */
	public boolean isWay(int x, int y, boolean checkCollision) {
		boolean isWay = false;
		if ((y < sizeY && y >= 0 && x < sizeX && x >= 0) && (labyrinth[x][y].isWay())) {
			isWay = true;
			if (checkCollision && this.checkCollision()){
				isWay = false;
			}
		}
		return isWay;
	}


	/**
	 * Gets the mouse.
	 *
	 * @return the mouse
	 */
	public Mouse getMouse() {
		return mouse; 
	}

	/**
	 * Gets the mouse2.
	 *
	 * @return the mouse2
	 */
	public Mouse getMouse2() {
		return mouse2; 
	}

	/**
	 * Draw labyrinth bitmaps.
	 */
	private void drawLabyrinthBitmaps() {
		Graphics g = imgMouse.getGraphics();
		g.setColor(Color.red);
		g.fillRect(0,0,WIDTH,HEIGHT);

		g = imgMouse2.getGraphics();
		g.setColor(Color.white);
		g.fillRect(0,0,WIDTH,HEIGHT);

		g = imgPath.getGraphics();
		g.setColor(Color.green);
		g.fillRect(0,0,WIDTH,HEIGHT);		

		g = imgVisited.getGraphics();
		g.setColor(Color.blue);
		g.fillRect(0,0,WIDTH,HEIGHT);

		g = imgVisited2.getGraphics();
		g.setColor(Color.yellow);
		g.fillRect(0,0,WIDTH,HEIGHT);

		g = imgVisited3.getGraphics();
		g.setColor(Color.blue);
		g.fillRect(0,0,WIDTH/2,HEIGHT);
		g.setColor(Color.yellow);
		g.fillRect(WIDTH/2,0,WIDTH,HEIGHT);

		g = imgWall.getGraphics();
		g.setColor(Color.lightGray);
		g.fillRect(0,0,WIDTH,HEIGHT);

		g.setColor(Color.DARK_GRAY);
		g.drawLine(1,5,5,5);
		g.drawLine(WIDTH-1,HEIGHT-1,WIDTH-1,1);

		g = imgWay.getGraphics();
		g.setColor(Color.black);
		g.fillRect(0,0,WIDTH,HEIGHT);
	}
}
