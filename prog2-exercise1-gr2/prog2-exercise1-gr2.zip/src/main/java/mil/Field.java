package mil;


import java.util.HashSet;
import java.util.Set;

/**
 * The Class Field.
 */

//TODO Observer
public class Field extends Subject{

	/** The wall. */
	private boolean wall    = false;
	
	/** The way. */
	private boolean way     = false;
	
	/** The path. */
	private boolean path    = false;
	
	/** The visited. */
	private boolean visited = false;
	
	/** The names. */
	private Set<String> names = new HashSet<>();
	
	/**
	 * Sets the wall.
	 */
	public void setWall() {
		wall = true; 
		way = false;
	}
	
	/**
	 * Sets the way.
	 */
	public void setWay() {
		wall = false; 
		way  = true;
	}
	
	/**
	 * Sets the path.
	 */
	public void setPath() {
		path = true;
	}
	
	/**
	 * Sets the checks if is visited.
	 *
	 * @param name the new checks if is visited
	 */
	public void setIsVisited(String name) {
		visited = true;
		names.add(name);
		notifyObservers(this);
	}
	
	/**
	 * Clear visited.
	 */
	public void clearVisited() {
		visited = false;
	}
	
	/**
	 * Checks if is wall.
	 *
	 * @return true, if is wall
	 */
	public boolean isWall() {
		return wall;
	}

	/**
	 * Checks if is way.
	 *
	 * @return true, if is way
	 */
	public boolean isWay() {
		return way;
	}

	/**
	 * Checks if is path.
	 *
	 * @return true, if is path
	 */
	public boolean isPath() {
		return path;
	}

	/**
	 * Checks if is visited.
	 *
	 * @return true, if is visited
	 */
	public boolean isVisited() {
		return visited;
	}
	
	/**
	 * Checks if is visited.
	 *
	 * @param name the name
	 * @return true, if is visited
	 */
	public boolean isVisited(String name) {
		boolean visitedByName = false;
		if (names.contains(name) && visited){
			visitedByName = true;
		}
		return visitedByName;
	}
	
	/**
	 * Gets the names.
	 *
	 * @return the names
	 */
	public Set<String> getNames() {
		return names;
	}
}
