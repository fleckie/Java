package mil;

public class  Wall extends Field {

    Wall(){
        setWall();
    }
}
