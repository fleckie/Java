package mil;

public class Way extends Field {
    Way(){
        setWay();
    }
}
