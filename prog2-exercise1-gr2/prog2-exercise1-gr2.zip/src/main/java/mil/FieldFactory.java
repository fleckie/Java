package mil;

public class FieldFactory {


    public static Field setField(char symbol) {
        switch (symbol) {
            case ' ':
                return new Way();
            case 'X':
                return new Wall();
        }
        return null;
    }
}


