package mil;

import java.util.ArrayList;

public class Subject {

    private ArrayList<Observer> observerList = new ArrayList <Observer>();

    public void add(Observer o){
        observerList.add(o);
    }
    public void notifyObservers(Field s){
        observerList.forEach( observer -> observer.update(s));
    };
}
