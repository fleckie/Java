package mil;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Vector;

import static org.junit.jupiter.api.Assertions.*;
class LabyrinthTest{

     Labyrinth lab;

    @BeforeEach
    void setup(){
    lab = new Labyrinth();
    }

    @Test
    void testReadLabyrinth_Scenario1() {

        Vector<String> actual = lab.readLabyrinth("./fields/test01.txt");
        String expected = "X X";
        assertEquals(expected, actual.get(0));
        expected = " XX";
        assertEquals(expected, actual.get(1));
    }

    @Test
    void testCreateLabyrinth_Scenario1() {
        Vector<String> v = new Vector<>();
        v.add("X X X");

       Field[][] actual = lab.createLabFromFile(v);
       assertTrue(actual[0][0].isWall());
    }




}
